#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_06
#include <TestDefaultDeviceTypeInit.hpp>
