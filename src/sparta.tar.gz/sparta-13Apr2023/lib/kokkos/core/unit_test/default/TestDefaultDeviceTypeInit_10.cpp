#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_10
#include <TestDefaultDeviceTypeInit.hpp>
