#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_02
#include <TestDefaultDeviceTypeInit.hpp>
