#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_18
#include <TestDefaultDeviceTypeInit.hpp>
