#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_01
#include <TestDefaultDeviceTypeInit.hpp>
