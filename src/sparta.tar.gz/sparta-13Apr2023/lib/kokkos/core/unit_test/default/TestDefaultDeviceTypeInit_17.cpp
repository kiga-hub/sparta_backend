#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_17
#include <TestDefaultDeviceTypeInit.hpp>
