#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_04
#include <TestDefaultDeviceTypeInit.hpp>
