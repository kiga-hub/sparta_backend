#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_15
#include <TestDefaultDeviceTypeInit.hpp>
