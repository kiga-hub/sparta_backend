#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_13
#include <TestDefaultDeviceTypeInit.hpp>
