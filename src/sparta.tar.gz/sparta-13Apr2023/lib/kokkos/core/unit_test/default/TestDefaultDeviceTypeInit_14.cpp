#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_14
#include <TestDefaultDeviceTypeInit.hpp>
