#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_03
#include <TestDefaultDeviceTypeInit.hpp>
