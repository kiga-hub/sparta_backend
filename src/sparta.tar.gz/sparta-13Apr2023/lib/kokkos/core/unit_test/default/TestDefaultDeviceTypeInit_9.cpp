#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_09
#include <TestDefaultDeviceTypeInit.hpp>
