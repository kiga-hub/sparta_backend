#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_05
#include <TestDefaultDeviceTypeInit.hpp>
