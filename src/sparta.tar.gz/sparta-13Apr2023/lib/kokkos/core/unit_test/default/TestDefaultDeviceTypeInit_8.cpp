#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_08
#include <TestDefaultDeviceTypeInit.hpp>
