#define KOKKOS_DEFAULTDEVICETYPE_INIT_TEST_11
#include <TestDefaultDeviceTypeInit.hpp>
