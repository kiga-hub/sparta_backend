# HS hard-sphere collision model parameters for each species

# diameter (m)
# omega
# tref
# alpha

Ar  3.657896777921330e-10 0.50  273.15  1.0
